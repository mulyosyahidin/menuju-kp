<?php

for ($i = 0; $i < 10; $i++) {
  //kode disini
}
for ($i = 0; $i < 10; $i++) : //colon syntax
  //kode disini
endfor;

foreach (array() as $tunggal) {
  //
}
foreach (array() as $tunggal) :
  //
endforeach;

while (true) {
  //
}
while (true) :
  //
endwhile;