<?php
$students = array(
  array(
    'id' => 1,
    'nama' => 'Nasim Jailani',
    'semester' => 5,
    'hp' => '0957 5274 9001',
    'email' => 'bakidin.farida@prabowo.asia',
    'prodi' => array(
      'kode' => 'B',
      'nama' => 'Teknik Sipil'
    )
  ),
  array(
    'id' => 2,
    'nama' => 'Talia Safitri',
    'semester' => 8,
    'hp' => '(+62) 551 8049 0072',
    'email' => 'nrahayu@gmail.com',
    'prodi' => array(
      'kode' => 'F',
      'nama' => 'Sistem Informasi'
    )
  ),
  array(
    'id' => 3,
    'nama' => 'Kemal Wacana',
    'semester' => 3,
    'hp' => '(+62) 22 4332 334',
    'email' => 'elvina28@yahoo.com',
    'prodi' => array(
      'kode' => 'E',
      'nama' => 'Arsitektur'
    )
  ),
  array(
    'id' => 4,
    'nama' => 'Dodo Putra',
    'semester' => 3,
    'hp' => '(+62) 744 8775 1313',
    'email' => 'kiandra.mansur@rahmawati.net',
    'prodi' => array(
      'kode' => 'A',
      'nama' => 'Informatika'
    )
  ),
  array(
    'id' => 5,
    'nama' => 'Cornelia Pratiwi',
    'semester' => 3,
    'hp' => '(+62) 885 4027 147',
    'email' => 'gmarpaung@halim.mil.id',
    'prodi' => array(
      'kode' => 'E',
      'nama' => 'Arsitektur'
    )
  ),
  array(
    'id' => 6,
    'nama' => 'Ibun Waluyo',
    'semester' => 8,
    'hp' => '(+62) 903 8600 6859',
    'email' => 'liman.manullang@yahoo.co.id',
    'prodi' => array(
      'kode' => 'B',
      'nama' => 'Teknik Sipil'
    )
  ),
  array(
    'id' => 7,
    'nama' => 'Cindy Laksita',
    'semester' => 2,
    'hp' => '(+62) 216 3423 433',
    'email' => 'salimah70@utami.sch.id',
    'prodi' => array(
      'kode' => 'B',
      'nama' => 'Teknik Sipil'
    )
  ),
  array(
    'id' => 8,
    'nama' => 'Balapati Lukita Maulana',
    'semester' => 8,
    'hp' => '(+62) 659 3411 335',
    'email' => 'jessica.adriansyah@wasita.my.id',
    'prodi' => array(
      'kode' => 'C',
      'nama' => 'Teknik Mesin'
    )
  ),
  array(
    'id' => 9,
    'nama' => 'Nurul Lestari',
    'semester' => 5,
    'hp' => '0613 8445 3114',
    'email' => 'situmorang.ratna@yahoo.co.id',
    'prodi' => array(
      'kode' => 'D',
      'nama' => 'Teknik Elektro'
    )
  ),
  array(
    'id' => 10,
    'nama' => 'Makuta Narpati',
    'semester' => 8,
    'hp' => '(+62) 313 8545 4269',
    'email' => 'byuliarti@gmail.com',
    'prodi' => array(
      'kode' => 'B',
      'nama' => 'Teknik Sipil'
    )
  ),
);
?>
<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <title>Data Mahasiswa Pendaftar</title>

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">

  <style>
    body {
      padding-top: 50px;
    }
  </style>
</head>

<body>
  <div class="container">
    <div class="row">
      <div class="col-10 mx-auto">
        <h3 class="display-4">Data Mahasiswa</h3>

        <p>Pendaftaran UKM XYZ</p>
        <p>Syarat diterima: <code>semester >= 4</code></p>

        <table class="table table-striped">
          <thead class="thead-dark">
            <th scope="col">ID</th>
            <th scope="col">Nama</th>
            <th scope="col">Semester</th>
            <th scope="col">No. HP</th>
            <th scope="col">Email</th>
            <th scope="col">Prodi</th>
            <th scope="col">Diterima</th>
          </thead>
          <tbody>
            
          </tbody>
        </table>
      </div>
    </div>
  </div>
</body>

</html>