<?php

/**
 * 1. Ambil data input formulir, yaitu jenis kelamin, tinggi dan berat badan
 */

/**
 * 2. Buat fungsi untuk menghitung bmi
 * 
 *    Fungsi ini menerima 2 argumen, yaitu `tinggi` dan `berat`
 *    dan mengembalikan (return) hasil perhitungan BMI (tipe data: float)
 */

/**
 * 3. Buat fungsi untuk menentukan kategori BMI
 * 
 *    Fungsi ini berguna untuk menentukan kategori BMI
 *    berdasarkan hasil perhitungan BMI.
 *    Fungsi ini menerima 2 argumen, yaitu `hasil bmi` dan `jenis kelamin`
 *    dan mengembalikan (return) kategori BMI (tipe data: string).
 * 
 *    Di dalam fungsi, buat percabangan berdasarkan `jenis kelamin`,
 *    kemudian tentukan kategori BMI masing-masing jenis kelamin berdasarkan `hasil bmi`
 */

/**
 * 4. Panggil fungsi penghitung bmi dengan memberikan argumen yang diperlukan
 * 5. Panggil fungsi kategori bmi dengan memberikan argumen yang diperlukan
 * 6. Tampilkan data ke HTML
 */
