<?php
$nama = 'martin ms';

echo base64_encode($nama); //encode base54
echo '<br>';

$url = 'https://www.google.com/';
echo urlencode($url);
